# =========================================================
# TURBO DRIVE - MOBILE
# Python + Kivy
# =========================================================

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.progressbar import ProgressBar
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.core.window import Window


# =========================================================
# بيانات اللعبة
# =========================================================

money = 0.0

car_levels = {
    "engine": 1,
    "turbo": 1,
    "tires": 1,
    "bumper": 1,
    "hood": 1,
    "fuel": 1,
}

selected_part = "engine"


# =========================================================
# السيارات
# =========================================================

cars = [
    {"name": "STARTER", "price": 0, "max_level": 10},
    {"name": "STREET", "price": 5000, "max_level": 25},
    {"name": "SPORT", "price": 25000, "max_level": 50},
    {"name": "SUPER", "price": 100000, "max_level": 100},
    {"name": "ULTIMATE", "price": 1000000, "max_level": None},
]

owned_cars = {0}
selected_car = 0


# =========================================================
# أسماء القطع
# =========================================================

part_names = {
    "engine": "ENGINE",
    "turbo": "TURBO",
    "tires": "TIRES",
    "bumper": "BUMPER",
    "hood": "HOOD",
    "fuel": "FUEL TANK",
}


# =========================================================
# أسعار القطع
# =========================================================

part_prices = {
    "engine": 1000,
    "turbo": 500,
    "tires": 30,
    "bumper": 50,
    "hood": 60,
    "fuel": 100,
}


# =========================================================
# فوائد القطع
# =========================================================

part_benefits = {
    "engine": "MORE POWER",
    "turbo": "MORE SPEED",
    "tires": "BETTER CONTROL",
    "bumper": "MORE MONEY",
    "hood": "MORE DURABILITY",
    "fuel": "MORE FUEL",
}


# =========================================================
# مضاعفات القطع
# =========================================================

part_multipliers = {
    "tires": 1,
    "bumper": 2,
    "hood": 3,
    "fuel": 4,
    "turbo": 5,
    "engine": 10,
}


parts = [
    "engine",
    "turbo",
    "tires",
    "bumper",
    "hood",
    "fuel",
]


# =========================================================
# الألوان
# =========================================================

BG = (0.04, 0.05, 0.07, 1)
BLUE = (0.05, 0.45, 0.95, 1)
DARK_BLUE = (0.03, 0.20, 0.40, 1)
GRAY = (0.16, 0.18, 0.22, 1)
WHITE = (0.95, 0.95, 0.95, 1)
GOLD = (0.95, 0.70, 0.15, 1)
GREEN = (0.15, 0.75, 0.35, 1)
RED = (0.85, 0.05, 0.05, 1)
BLACK = (0.03, 0.03, 0.03, 1)


# =========================================================
# معلومات السيارة الحالية
# =========================================================

def get_max_level():
    return cars[selected_car]["max_level"]


def get_car_name():
    return cars[selected_car]["name"]


def get_price(part):

    level = car_levels[part]
    max_level = get_max_level()

    if max_level is not None and level >= max_level:
        return None

    return int(
        part_prices[part] * (1.5 ** (level - 1))
    )


# =========================================================
# مضاعف المال
# =========================================================

def get_profit_multiplier():

    multiplier = 1.0

    for part in parts:

        purchased_levels = car_levels[part] - 1

        if purchased_levels > 0:

            multiplier += (
                purchased_levels
                * part_multipliers[part]
            )

    return multiplier


# =========================================================
# مواصفات السيارة
# =========================================================

def get_speed():

    engine_bonus = (
        (car_levels["engine"] - 1) * 10
    )

    turbo_bonus = (
        (car_levels["turbo"] - 1) * 20
    )

    return 100 + engine_bonus + turbo_bonus


def get_fuel():

    return (
        100
        + (car_levels["fuel"] - 1) * 25
    )


def get_control():

    return (
        100
        + (car_levels["tires"] - 1) * 10
    )


def get_durability():

    return (
        100
        + (car_levels["hood"] - 1) * 10
    )


# =========================================================
# سرعة اللاعب في السباق
# =========================================================

def get_race_speed():

    engine_speed = (
        (car_levels["engine"] - 1)
        * 0.03
    )

    turbo_speed = (
        (car_levels["turbo"] - 1)
        * 0.05
    )

    return (
        0.30
        + engine_speed
        + turbo_speed
    )


# =========================================================
# زر مساعد
# =========================================================

def make_button(text, callback=None, height=55):

    button = Button(
        text=text,
        size_hint_y=None,
        height=dp(height),
        background_normal="",
        background_color=DARK_BLUE,
        color=WHITE,
        font_size=sp(16),
    )

    if callback is not None:

        button.bind(
            on_press=callback
        )

    return button


# =========================================================
# شكل السيارة
# =========================================================

class CarWidget(Widget):

    def __init__(
        self,
        car_color,
        police=False,
        **kwargs
    ):

        super().__init__(**kwargs)

        self.car_color = car_color
        self.police = police

        with self.canvas:

            # جسم السيارة
            Color(*self.car_color)

            self.body = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[dp(8)]
            )

            # زجاج السيارة
            Color(
                0.70,
                0.85,
                1.0,
                1
            )

            self.window = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[dp(5)]
            )

            # العجلات
            Color(*BLACK)

            self.wheel1 = Ellipse(
                pos=(0, 0),
                size=(dp(11), dp(11))
            )

            self.wheel2 = Ellipse(
                pos=(0, 0),
                size=(dp(11), dp(11))
            )

            # أضواء الشرطة
            if self.police:

                Color(
                    1,
                    0.05,
                    0.05,
                    1
                )

                self.red_light = RoundedRectangle(
                    pos=(0, 0),
                    size=(dp(10), dp(5)),
                    radius=[dp(2)]
                )

                Color(
                    0.1,
                    0.3,
                    1,
                    1
                )

                self.blue_light = RoundedRectangle(
                    pos=(0, 0),
                    size=(dp(10), dp(5)),
                    radius=[dp(2)]
                )

        self.bind(
            pos=self.update_graphics,
            size=self.update_graphics
        )

        self.update_graphics()

    def update_graphics(self, *args):

        self.body.pos = self.pos
        self.body.size = self.size

        self.window.pos = (
            self.x + self.width * 0.32,
            self.y + self.height * 0.35
        )

        self.window.size = (
            self.width * 0.36,
            self.height * 0.35
        )

        self.wheel1.pos = (
            self.x + self.width * 0.10,
            self.y - dp(3)
        )

        self.wheel2.pos = (
            self.x + self.width * 0.68,
            self.y - dp(3)
        )

        if self.police:

            self.red_light.pos = (
                self.x + self.width * 0.40,
                self.top - dp(5)
            )

            self.blue_light.pos = (
                self.x + self.width * 0.55,
                self.top - dp(5)
            )


# =========================================================
# شاشة التحميل
# =========================================================

class LoadingScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(30),
            spacing=dp(20),
        )

        self.add_widget(self.layout)

        self.layout.add_widget(
            Label(
                text="TURBO DRIVE",
                font_size=sp(32),
                color=BLUE,
            )
        )

        self.layout.add_widget(
            Label(
                text="CHALLENGE YOURSELF.\n"
                     "BECOME THE FASTEST.",
                font_size=sp(18),
                color=WHITE,
            )
        )

        self.progress = ProgressBar(
            max=100,
            value=0,
            size_hint_y=None,
            height=dp(25),
        )

        self.layout.add_widget(
            self.progress
        )

        self.percent = Label(
            text="0%",
            font_size=sp(18),
            color=BLUE,
        )

        self.layout.add_widget(
            self.percent
        )

        self.layout.add_widget(
            Label(
                text="REACH YOUR LIMIT.\n"
                     "TAKE A SCREENSHOT AND SHARE IT.",
                font_size=sp(14),
                color=WHITE,
            )
        )

        Clock.schedule_interval(
            self.loading_update,
            0.05
        )

    def loading_update(self, dt):

        self.progress.value += 2

        self.percent.text = (
            str(int(self.progress.value))
            + "%"
        )

        if self.progress.value >= 100:

            Clock.unschedule(
                self.loading_update
            )

            self.manager.current = "home"


# =========================================================
# الشاشة الرئيسية
# =========================================================

class HomeScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(25),
            spacing=dp(15),
        )

        self.add_widget(self.layout)

        self.title = Label(
            text="TURBO DRIVE",
            font_size=sp(32),
            color=BLUE,
            size_hint_y=None,
            height=dp(60),
        )

        self.layout.add_widget(self.title)

        self.money_label = Label(
            text="$0.00",
            font_size=sp(24),
            color=GOLD,
            size_hint_y=None,
            height=dp(45),
        )

        self.layout.add_widget(self.money_label)

        self.multiplier_label = Label(
            text="MONEY x1",
            font_size=sp(16),
            color=WHITE,
            size_hint_y=None,
            height=dp(35),
        )

        self.layout.add_widget(
            self.multiplier_label
        )

        self.money_button = Button(
            text="$",
            font_size=sp(70),
            color=(0.15, 0.10, 0.02, 1),
            background_normal="",
            background_color=GOLD,
            size_hint=(None, None),
            size=(dp(190), dp(190)),
            pos_hint={"center_x": 0.5},
        )

        self.money_button.bind(
            on_press=self.collect_money
        )

        self.layout.add_widget(
            self.money_button
        )

        self.layout.add_widget(
            Label(
                text="TAP TO EARN",
                font_size=sp(15),
                color=WHITE,
                size_hint_y=None,
                height=dp(30),
            )
        )

        self.layout.add_widget(
            make_button(
                "MODIFICATIONS",
                self.open_modifications
            )
        )

        self.layout.add_widget(
            make_button(
                "CAR INFO",
                self.open_specs
            )
        )

        self.layout.add_widget(
            make_button(
                "POLICE RUN",
                self.open_race
            )
        )

        self.layout.add_widget(
            make_button(
                "CARS",
                self.open_cars
            )
        )

    def on_pre_enter(self):
        self.refresh()

    def refresh(self):

        self.money_label.text = (
            "$" + f"{money:.2f}"
        )

        self.multiplier_label.text = (
            "MONEY x"
            + f"{get_profit_multiplier():.0f}"
        )

    def collect_money(self, instance):

        global money

        money += get_profit_multiplier()

        self.refresh()

    def open_modifications(self, instance):
        self.manager.current = "mods"

    def open_specs(self, instance):
        self.manager.current = "specs"

    def open_race(self, instance):
        self.manager.current = "race"

    def open_cars(self, instance):
        self.manager.current = "cars"


# =========================================================
# شاشة التعديلات
# =========================================================

class ModificationsScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(15),
            spacing=dp(10),
        )

        self.add_widget(self.layout)

        self.header = BoxLayout(
            size_hint_y=None,
            height=dp(55),
        )

        self.title = Label(
            text="CAR MODIFICATIONS",
            font_size=sp(22),
            color=BLUE,
        )

        self.money_label = Label(
            text="$0.00",
            font_size=sp(18),
            color=GOLD,
        )

        self.header.add_widget(self.title)
        self.header.add_widget(self.money_label)

        self.layout.add_widget(
            self.header
        )

        self.parts_grid = GridLayout(
            cols=2,
            spacing=dp(8),
            size_hint_y=None,
        )

        self.parts_grid.bind(
            minimum_height=self.parts_grid.setter(
                "height"
            )
        )

        self.layout.add_widget(
            self.parts_grid
        )

        for part in parts:

            button = make_button(
                part_names[part],
                lambda instance, p=part:
                self.select_part(p),
                height=60,
            )

            self.parts_grid.add_widget(
                button
            )

        self.info_label = Label(
            text="",
            font_size=sp(15),
            color=WHITE,
            halign="center",
            valign="middle",
        )

        self.info_label.bind(
            size=lambda instance, value:
            setattr(
                instance,
                "text_size",
                value
            )
        )

        self.layout.add_widget(
            self.info_label
        )

        self.buy_button = make_button(
            "BUY",
            self.buy_upgrade,
            height=60,
        )

        self.layout.add_widget(
            self.buy_button
        )

        self.layout.add_widget(
            make_button(
                "BACK",
                self.go_back,
                height=50,
            )
        )

    def on_pre_enter(self):
        self.refresh()

    def select_part(self, part):

        global selected_part

        selected_part = part

        self.refresh()

    def refresh(self):

        self.money_label.text = (
            "$" + f"{money:.2f}"
        )

        level = car_levels[selected_part]
        price = get_price(selected_part)
        multiplier = part_multipliers[selected_part]

        total_bonus = (
            (level - 1)
            * multiplier
        )

        max_level = get_max_level()

        max_text = (
            "∞"
            if max_level is None
            else str(max_level)
        )

        next_text = (
            "MAX LEVEL"
            if price is None
            else "$" + str(price)
        )

        self.info_label.text = (
            f"CAR: {get_car_name()}\n\n"
            f"{part_names[selected_part]}\n\n"
            f"LEVEL: {level}\n"
            f"{part_benefits[selected_part]}\n\n"
            f"THIS PART: +x{multiplier}\n"
            f"PART BONUS: +x{total_bonus}\n"
            f"TOTAL MONEY: x"
            f"{get_profit_multiplier():.0f}\n\n"
            f"CAR MAX LEVEL: {max_text}\n"
            f"NEXT UPGRADE: {next_text}"
        )

        if price is None:
            self.buy_button.text = "MAX LEVEL"
        else:
            self.buy_button.text = (
                f"BUY  ${price}"
            )

    def buy_upgrade(self, instance):

        global money

        price = get_price(selected_part)

        if price is None:

            self.info_label.text = (
                "MAX LEVEL REACHED"
            )

            return

        if money >= price:

            money -= price

            car_levels[selected_part] += 1

            self.refresh()

        else:

            self.info_label.text = (
                f"NOT ENOUGH MONEY\n\n"
                f"YOU NEED "
                f"${price - money:.2f} MORE"
            )

    def go_back(self, instance):
        self.manager.current = "home"


# =========================================================
# شاشة السيارات
# =========================================================

class CarsScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(15),
            spacing=dp(10),
        )

        self.add_widget(self.layout)

        self.header = Label(
            text="CARS",
            font_size=sp(28),
            color=BLUE,
            size_hint_y=None,
            height=dp(55),
        )

        self.layout.add_widget(self.header)

        self.money_label = Label(
            text="$0.00",
            font_size=sp(18),
            color=GOLD,
            size_hint_y=None,
            height=dp(35),
        )

        self.layout.add_widget(
            self.money_label
        )

        scroll = ScrollView()

        self.cars_grid = GridLayout(
            cols=1,
            spacing=dp(10),
            padding=dp(5),
            size_hint_y=None,
        )

        self.cars_grid.bind(
            minimum_height=self.cars_grid.setter(
                "height"
            )
        )

        scroll.add_widget(
            self.cars_grid
        )

        self.layout.add_widget(
            scroll
        )

        self.layout.add_widget(
            make_button(
                "BACK",
                self.go_back,
                height=55,
            )
        )

    def on_pre_enter(self):
        self.refresh()

    def refresh(self):

        self.money_label.text = (
            "$" + f"{money:.2f}"
        )

        self.cars_grid.clear_widgets()

        for index, car in enumerate(cars):

            owned = index in owned_cars
            selected = index == selected_car

            max_text = (
                "∞"
                if car["max_level"] is None
                else str(car["max_level"])
            )

            card = BoxLayout(
                orientation="vertical",
                size_hint_y=None,
                height=dp(145),
                spacing=dp(5),
                padding=dp(5),
            )

            info = Label(
                text=(
                    f"{car['name']}\n"
                    f"PRICE: ${car['price']}\n"
                    f"MAX LEVEL: {max_text}"
                ),
                font_size=sp(16),
                color=WHITE,
                halign="center",
                valign="middle",
            )

            info.bind(
                size=lambda instance, value:
                setattr(
                    instance,
                    "text_size",
                    value
                )
            )

            card.add_widget(
                info
            )

            if selected:
                action_text = "SELECTED"
            elif owned:
                action_text = "SELECT"
            else:
                action_text = (
                    f"BUY  ${car['price']}"
                )

            action_button = Button(
                text=action_text,
                size_hint_y=None,
                height=dp(50),
                background_normal="",
                background_color=(
                    GREEN
                    if selected
                    else DARK_BLUE
                ),
                color=WHITE,
                font_size=sp(16),
            )

            action_button.bind(
                on_press=lambda instance, i=index:
                self.select_or_buy(i)
            )

            card.add_widget(
                action_button
            )

            self.cars_grid.add_widget(
                card
            )

    def select_or_buy(self, index):

        global money
        global selected_car

        if index in owned_cars:

            selected_car = index

            self.header.text = (
                f"SELECTED: "
                f"{cars[index]['name']}"
            )

            self.refresh()

            return

        price = cars[index]["price"]

        if money >= price:

            money -= price

            owned_cars.add(index)

            selected_car = index

            self.header.text = (
                f"PURCHASED: "
                f"{cars[index]['name']}"
            )

            self.refresh()

        else:

            self.header.text = (
                f"NEED "
                f"${price - money:.2f} MORE"
            )

    def go_back(self, instance):
        self.manager.current = "home"


# =========================================================
# شاشة سباق الشرطة
# =========================================================

class PoliceRunScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.running = False
        self.elapsed = 0.0
        self.difficulty = 0

        # -------------------------------------------------
        # فلوس الجولة
        # -------------------------------------------------

        self.run_money = 0.0

        self.base_reward = 0.50

        # -------------------------------------------------
        # الوقود
        # -------------------------------------------------

        self.max_fuel = get_fuel()
        self.current_fuel = self.max_fuel

        # استهلاك الوقود في الثانية
        self.fuel_consumption = 0.80

        # -------------------------------------------------
        # مواقع اللاعب والشرطة
        # -------------------------------------------------

        self.player_x = 0.45
        self.player_y = 0.15

        self.police_x = 0.45
        self.police_y = 0.75

        # -------------------------------------------------
        # سرعة الشرطة
        # -------------------------------------------------

        self.police_speed = 0.050

        self.police_max_speed = 0.120

        self.police_acceleration = 0.006

        # -------------------------------------------------
        # المربعات الذهبية
        # -------------------------------------------------

        self.star_count = 3
        self.star_labels = []

        # -------------------------------------------------
        # الاتجاهات
        # -------------------------------------------------

        self.directions = {
            "up": False,
            "down": False,
            "left": False,
            "right": False,
        }

        # -------------------------------------------------
        # الواجهة
        # -------------------------------------------------

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(8),
            spacing=dp(8),
        )

        self.add_widget(
            self.layout
        )

        # -------------------------------------------------
        # عنوان السباق
        # -------------------------------------------------

        self.status = Label(
            text="POLICE RUN",
            font_size=sp(20),
            color=BLUE,
            size_hint_y=None,
            height=dp(38),
        )

        self.layout.add_widget(
            self.status
        )

        # -------------------------------------------------
        # الوقت والمكافأة
        # -------------------------------------------------

        self.timer_reward = BoxLayout(
            size_hint_y=None,
            height=dp(38),
            spacing=dp(6),
        )

        self.timer_label = Label(
            text="TIME: 15s",
            font_size=sp(16),
            color=WHITE,
        )

        self.reward_label = Label(
            text="REWARD: $0.50",
            font_size=sp(16),
            color=GOLD,
        )

        self.run_money_label = Label(
            text="RUN: $0.00",
            font_size=sp(16),
            color=GREEN,
        )

        self.timer_reward.add_widget(
            self.timer_label
        )

        self.timer_reward.add_widget(
            self.reward_label
        )

        self.timer_reward.add_widget(
            self.run_money_label
        )

        self.layout.add_widget(
            self.timer_reward
        )

        # -------------------------------------------------
        # الوقود فوق السباق
        # -------------------------------------------------

        self.fuel_label = Label(
            text="FUEL: 100 / 100",
            font_size=sp(16),
            color=WHITE,
            size_hint_y=None,
            height=dp(32),
        )

        self.layout.add_widget(
            self.fuel_label
        )

        # -------------------------------------------------
        # ساحة اللعب
        # -------------------------------------------------

        self.arena = FloatLayout(
            size_hint_y=0.60,
        )

        self.layout.add_widget(
            self.arena
        )

        # -------------------------------------------------
        # السيارة الزرقاء
        # -------------------------------------------------

        self.player = CarWidget(
            car_color=BLUE,
            police=False,
            size_hint=(None, None),
            size=(dp(58), dp(35)),
        )

        # -------------------------------------------------
        # سيارة الشرطة الحمراء
        # -------------------------------------------------

        self.police = CarWidget(
            car_color=RED,
            police=True,
            size_hint=(None, None),
            size=(dp(62), dp(37)),
        )

        self.arena.add_widget(
            self.player
        )

        self.arena.add_widget(
            self.police
        )

        # -------------------------------------------------
        # D-PAD
        # -------------------------------------------------

        self.controls = GridLayout(
            cols=3,
            rows=3,
            spacing=dp(4),
            size_hint=(None, None),
            width=dp(180),
            height=dp(165),
            pos_hint={
                "center_x": 0.5
            },
        )

        self.layout.add_widget(
            self.controls
        )

        self.controls.add_widget(
            Widget()
        )

        self.up_button = make_button(
            "↑",
            height=52,
        )

        self.controls.add_widget(
            self.up_button
        )

        self.controls.add_widget(
            Widget()
        )

        self.left_button = make_button(
            "←",
            height=52,
        )

        self.controls.add_widget(
            self.left_button
        )

        self.center_button = Button(
            text="",
            size_hint_y=None,
            height=dp(52),
            background_normal="",
            background_color=GRAY,
        )

        self.controls.add_widget(
            self.center_button
        )

        self.right_button = make_button(
            "→",
            height=52,
        )

        self.controls.add_widget(
            self.right_button
        )

        self.controls.add_widget(
            Widget()
        )

        self.down_button = make_button(
            "↓",
            height=52,
        )

        self.controls.add_widget(
            self.down_button
        )

        self.controls.add_widget(
            Widget()
        )

        self.bind_direction(
            self.up_button,
            "up"
        )

        self.bind_direction(
            self.down_button,
            "down"
        )

        self.bind_direction(
            self.left_button,
            "left"
        )

        self.bind_direction(
            self.right_button,
            "right"
        )

        Window.bind(
            on_touch_up=self.force_release_controls
        )

        # -------------------------------------------------
        # زر الرجوع
        # -------------------------------------------------

        self.layout.add_widget(
            make_button(
                "BACK",
                self.go_back,
                height=42,
            )
        )

    # =====================================================
    # ربط الاتجاه
    # =====================================================

    def bind_direction(
        self,
        button,
        direction
    ):

        button.bind(
            on_press=lambda instance:
            self.set_direction(
                direction,
                True
            )
        )

        button.bind(
            on_release=lambda instance:
            self.set_direction(
                direction,
                False
            )
        )

    # =====================================================
    # تغيير الاتجاه
    # =====================================================

    def set_direction(
        self,
        direction,
        value
    ):

        self.directions[direction] = value

    # =====================================================
    # تصفير التحكم
    # =====================================================

    def reset_controls(self):

        for direction in self.directions:

            self.directions[direction] = False

    # =====================================================
    # حماية من تعليق الأزرار
    # =====================================================

    def force_release_controls(
        self,
        window,
        touch
    ):

        self.reset_controls()

    # =====================================================
    # عند الدخول
    # =====================================================

    def on_pre_enter(self):

        self.start_run()

    # =====================================================
    # عند الخروج
    # =====================================================

    def on_leave(self):

        self.stop_run()

        self.transfer_run_money()

        self.reset_controls()

    # =====================================================
    # بدء الجولة
    # =====================================================

    def start_run(self):

        self.stop_run()

        self.running = True

        self.elapsed = 0.0

        self.difficulty = 0

        self.run_money = 0.0

        # السرعة الابتدائية للشرطة
        self.police_speed = 0.050

        self.star_count = 3

        # تحديث الوقود حسب مستوى الخزان
        self.max_fuel = get_fuel()

        self.current_fuel = self.max_fuel

        self.player_x = 0.45
        self.player_y = 0.15

        self.police_x = 0.45
        self.police_y = 0.75

        self.reset_controls()

        self.status.text = (
            "POLICE RUN"
        )

        self.timer_label.text = (
            "TIME: 15s"
        )

        self.reward_label.text = (
            "REWARD: $0.50"
        )

        self.run_money_label.text = (
            "RUN: $0.00"
        )

        self.fuel_label.text = (
            f"FUEL: "
            f"{self.current_fuel:.0f} / "
            f"{self.max_fuel:.0f}"
        )

        self.make_stars()

        self.update_positions()

        self.timer_event = Clock.schedule_interval(
            self.update_game,
            1 / 30
        )

    # =====================================================
    # إيقاف الجولة
    # =====================================================

    def stop_run(self):

        self.running = False

        if hasattr(
            self,
            "timer_event"
        ):

            Clock.unschedule(
                self.timer_event
            )

    # =====================================================
    # إنشاء المربعات الذهبية
    # =====================================================

    def make_stars(self):

        import random

        for star in self.star_labels:

            if star.parent:

                star.parent.remove_widget(
                    star
                )

        self.star_labels = []

        for _ in range(
            self.star_count
        ):

            star = Label(
                text="■",
                font_size=sp(27),
                color=GOLD,
                size_hint=(None, None),
                size=(dp(35), dp(35)),
            )

            star.pos_hint = {
                "x": random.uniform(
                    0.08,
                    0.85
                ),
                "y": random.uniform(
                    0.20,
                    0.85
                ),
            }

            self.arena.add_widget(
                star
            )

            self.star_labels.append(
                star
            )

        self.arena.remove_widget(
            self.player
        )

        self.arena.remove_widget(
            self.police
        )

        self.arena.add_widget(
            self.player
        )

        self.arena.add_widget(
            self.police
        )

    # =====================================================
    # نقل فلوس الجولة
    # =====================================================

    def transfer_run_money(self):

        global money

        if self.run_money > 0:

            money += self.run_money

            self.run_money = 0.0

            self.run_money_label.text = (
                "RUN: $0.00"
            )

    # =====================================================
    # تحديث اللعبة
    # =====================================================

    def update_game(self, dt):

        if not self.running:

            return

        # -------------------------------------------------
        # الوقت
        # -------------------------------------------------

        self.elapsed += dt

        # -------------------------------------------------
        # عداد 15 ثانية
        # -------------------------------------------------

        remaining = (
            15
            - int(
                self.elapsed % 15
            )
        )

        if remaining <= 0:

            remaining = 15

        self.timer_label.text = (
            f"TIME: {remaining}s"
        )

        # -------------------------------------------------
        # الصعوبة
        # -------------------------------------------------

        new_difficulty = int(
            self.elapsed // 15
        )

        if new_difficulty > self.difficulty:

            # كل 15 ثانية نعطي المكافأة
            for level in range(
                self.difficulty + 1,
                new_difficulty + 1
            ):

                reward = (
                    self.base_reward
                    * (
                        2 ** (level - 1)
                    )
                )

                self.run_money += reward

            self.difficulty = (
                new_difficulty
            )

            # المكافأة التالية تتضاعف
            next_reward = (
                self.base_reward
                * (
                    2 ** self.difficulty
                )
            )

            self.reward_label.text = (
                "REWARD: $"
                + f"{next_reward:.2f}"
            )

            # -------------------------------------------------
            # الشرطة تصير أسرع مع الصعوبة
            # -------------------------------------------------

            self.police_speed = min(
                self.police_max_speed,
                0.050
                + (
                    self.difficulty
                    * self.police_acceleration
                )
            )

            # -------------------------------------------------
            # زيادة المربعات الذهبية
            # -------------------------------------------------

            self.star_count = min(
                30,
                3 + self.difficulty
            )

            self.make_stars()

        # -------------------------------------------------
        # عرض فلوس الجولة
        # -------------------------------------------------

        self.run_money_label.text = (
            "RUN: $"
            + f"{self.run_money:.2f}"
        )

        # -------------------------------------------------
        # سرعة اللاعب حسب ENGINE + TURBO
        # -------------------------------------------------

        player_speed = get_race_speed()

        movement = (
            player_speed
            * dt
        )

        # -------------------------------------------------
        # هل اللاعب يحاول التحرك؟
        # -------------------------------------------------

        moving = any(
            self.directions.values()
        )

        # -------------------------------------------------
        # الوقود
        # -------------------------------------------------

        if moving and self.current_fuel > 0:

            self.current_fuel -= (
                self.fuel_consumption
                * dt
            )

            if self.current_fuel <= 0:

                self.current_fuel = 0

                self.reset_controls()

        self.fuel_label.text = (
            f"FUEL: "
            f"{self.current_fuel:.0f} / "
            f"{self.max_fuel:.0f}"
        )

        # -------------------------------------------------
        # حركة اللاعب
        # -------------------------------------------------

        if self.current_fuel > 0:

            if self.directions["up"]:

                self.player_y += movement

            if self.directions["down"]:

                self.player_y -= movement

            if self.directions["left"]:

                self.player_x -= movement

            if self.directions["right"]:

                self.player_x += movement

        # حدود اللاعب
        self.player_x = max(
            0.02,
            min(
                0.90,
                self.player_x
            )
        )

        self.player_y = max(
            0.02,
            min(
                0.90,
                self.player_y
            )
        )

        # -------------------------------------------------
        # حركة الشرطة
        # -------------------------------------------------

        dx = (
            self.player_x
            - self.police_x
        )

        dy = (
            self.player_y
            - self.police_y
        )

        police_movement = (
            self.police_speed
            * dt
        )

        if abs(dx) > 0.001:

            self.police_x += (
                police_movement
                * (
                    1
                    if dx > 0
                    else -1
                )
            )

        if abs(dy) > 0.001:

            self.police_y += (
                police_movement
                * (
                    1
                    if dy > 0
                    else -1
                )
            )

        # حدود الشرطة
        self.police_x = max(
            0.02,
            min(
                0.90,
                self.police_x
            )
        )

        self.police_y = max(
            0.02,
            min(
                0.90,
                self.police_y
            )
        )

        self.update_positions()

        # -------------------------------------------------
        # جمع المربعات الذهبية
        # كل مربع = $5
        # -------------------------------------------------

        collected_stars = []

        for star in self.star_labels[:]:

            star_x = star.pos_hint.get(
                "x",
                0
            )

            star_y = star.pos_hint.get(
                "y",
                0
            )

            distance_to_star = (
                (
                    self.player_x
                    - star_x
                ) ** 2
                +
                (
                    self.player_y
                    - star_y
                ) ** 2
            ) ** 0.5

            if distance_to_star < 0.08:

                self.run_money += 5.0

                collected_stars.append(
                    star
                )

        for star in collected_stars:

            if star.parent:

                star.parent.remove_widget(
                    star
                )

            if star in self.star_labels:

                self.star_labels.remove(
                    star
                )

        # تحديث فلوس الجولة
        self.run_money_label.text = (
            "RUN: $"
            + f"{self.run_money:.2f}"
        )

        # -------------------------------------------------
        # الاصطدام بالشرطة
        # -------------------------------------------------

        distance = (
            (
                self.player_x
                - self.police_x
            ) ** 2
            +
            (
                self.player_y
                - self.police_y
            ) ** 2
        ) ** 0.5

        if distance < 0.07:

            self.end_run()

    # =====================================================
    # تحديث أماكن السيارات
    # =====================================================

    def update_positions(self):

        self.player.pos_hint = {
            "x": self.player_x,
            "y": self.player_y,
        }

        self.police.pos_hint = {
            "x": self.police_x,
            "y": self.police_y,
        }

    # =====================================================
    # انتهاء الجولة
    # =====================================================

    def end_run(self):

        if not self.running:

            return

        self.stop_run()

        earned = self.run_money

        self.transfer_run_money()

        self.status.text = (
            "CAUGHT!  "
            f"EARNED: ${earned:.2f}"
        )

        self.run_money_label.text = (
            "RUN: $0.00"
        )

        self.reset_controls()

    # =====================================================
    # الرجوع
    # =====================================================

    def go_back(self, instance):

        self.stop_run()

        self.transfer_run_money()

        self.reset_controls()

        self.manager.current = "home"


# =========================================================
# شاشة معلومات السيارة
# =========================================================

class SpecsScreen(Screen):

    def __init__(self, **kwargs):

        super().__init__(**kwargs)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(20),
            spacing=dp(15),
        )

        self.add_widget(
            self.layout
        )

        self.layout.add_widget(
            Label(
                text="YOUR CAR",
                font_size=sp(30),
                color=BLUE,
                size_hint_y=None,
                height=dp(60),
            )
        )

        scroll = ScrollView()

        self.info = Label(
            text="",
            font_size=sp(17),
            color=WHITE,
            halign="left",
            valign="top",
            size_hint_y=None,
        )

        self.info.bind(
            texture_size=lambda instance, value:
            setattr(
                instance,
                "height",
                value[1]
            )
        )

        self.info.bind(
            width=lambda instance, value:
            setattr(
                instance,
                "text_size",
                (value, None)
            )
        )

        scroll.add_widget(
            self.info
        )

        self.layout.add_widget(
            scroll
        )

        self.layout.add_widget(
            make_button(
                "BACK",
                self.go_back,
                height=55,
            )
        )

    def on_pre_enter(self):

        self.refresh()

    def refresh(self):

        max_level = get_max_level()

        max_text = (
            "∞"
            if max_level is None
            else str(max_level)
        )

        self.info.text = (

            f"CAR: {get_car_name()}\n"
            f"MAX LEVEL: {max_text}\n\n"

            f"ENGINE\n"
            f"Level {car_levels['engine']}\n"
            f"Power bonus: +"
            f"{(car_levels['engine'] - 1) * 10}\n\n"

            f"TURBO\n"
            f"Level {car_levels['turbo']}\n"
            f"Maximum speed: "
            f"{get_speed()} KM/H\n\n"

            f"TIRES\n"
            f"Level {car_levels['tires']}\n"
            f"Control: "
            f"{get_control()}%\n\n"

            f"BUMPER\n"
            f"Level {car_levels['bumper']}\n"
            f"Money bonus: +x"
            f"{(car_levels['bumper'] - 1) * 2}\n\n"

            f"HOOD\n"
            f"Level {car_levels['hood']}\n"
            f"Durability: "
            f"{get_durability()}%\n\n"

            f"FUEL TANK\n"
            f"Level {car_levels['fuel']}\n"
            f"Fuel capacity: "
            f"{get_fuel()}\n\n"

            f"--------------------------------\n\n"

            f"TOTAL MONEY MULTIPLIER\n"
            f"x{get_profit_multiplier():.0f}"
        )

    def go_back(self, instance):

        self.manager.current = "home"


# =========================================================
# التطبيق
# =========================================================

class TurboDriveApp(App):

    def build(self):

        self.title = "TURBO DRIVE"

        manager = ScreenManager()

        manager.add_widget(
            LoadingScreen(
                name="loading"
            )
        )

        manager.add_widget(
            HomeScreen(
                name="home"
            )
        )

        manager.add_widget(
            ModificationsScreen(
                name="mods"
            )
        )

        manager.add_widget(
            SpecsScreen(
                name="specs"
            )
        )

        manager.add_widget(
            PoliceRunScreen(
                name="race"
            )
        )

        manager.add_widget(
            CarsScreen(
                name="cars"
            )
        )

        return manager


# =========================================================
# تشغيل التطبيق
# =========================================================

if __name__ == "__main__":

    TurboDriveApp().run()